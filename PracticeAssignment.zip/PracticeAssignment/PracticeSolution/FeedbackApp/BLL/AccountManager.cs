﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FeedbackApp.BLL
{
    public class AccountManager
    {
        public static bool Validate(string Username,string Password)
        {
            bool status = false;

            if(Username=="bhagyashri" && Password=="bhagya@12")
            {
                status = true;
            }

            return status;
        }
    }
}