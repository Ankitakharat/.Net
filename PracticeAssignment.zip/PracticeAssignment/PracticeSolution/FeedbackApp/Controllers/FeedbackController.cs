﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FeedbackApp.DAL;
using FeedbackApp.Models;

namespace FeedbackApp.Controllers
{
    public class FeedbackController : Controller
    {
        FeedbackContext entities = new FeedbackContext();
        // GET: Feedback
       
        public ActionResult AllFeedback(int ? Id)
        {
            List<Feedback> feedbacks = entities.Feedbacks.ToList();
            this.ViewData["feedbacks"] = feedbacks;

            return View();
        }
        [Authorize(Roles = "Admin")]
        public ActionResult View(int id)
        {
            var feedback = entities.Feedbacks.SingleOrDefault(p => p.Id == id);
            this.ViewData["feedbacks"] = feedback;
            return View();
        }

        [Authorize(Roles = "Admin")]
        public ActionResult Edit(int id)
        {
            var feedback = entities.Feedbacks.SingleOrDefault(p => p.Id == id);
            this.ViewData["feedbacks"] = feedback;
            return View(feedback);
        }

        [Authorize(Roles = "Admin")]
        [HttpPost]
        public ActionResult Edit(Feedback feedback)
        {
            if(ModelState.IsValid)
            {
                entities.Entry(feedback).State = System.Data.Entity.EntityState.Modified;
                entities.SaveChanges();
                return RedirectToAction("Allfeedback", "feedback");

            }

           
            return View(feedback);
        }

        [Authorize]
        public ActionResult Insert()
        {
            return View();
        }

       [HttpPost]
        public ActionResult Insert(Feedback feedback)
        {
            if(ModelState.IsValid)
            {
                feedback.Id = 5;
                entities.Feedbacks.Add(feedback);
                entities.SaveChanges();
                return RedirectToAction("AllFeedback", "feedback");
            }
            return View(feedback);
        }

        [Authorize]
        public ActionResult Delete(int id)
        {
            var feedback = entities.Feedbacks.SingleOrDefault(p => p.Id == id);
            entities.Feedbacks.Remove(feedback);
            entities.SaveChanges();
            return RedirectToAction("AllFeedback", "feedback");
        }
    }
}