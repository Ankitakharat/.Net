﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using FeedbackApp.Models;
using MySql.Data.EntityFramework;

namespace FeedbackApp.DAL
{
    [DbConfigurationType(typeof(MySqlEFConfiguration))]
    public class FeedbackContext:DbContext
    {
       public DbSet<Feedback> Feedbacks { get; set; }

        public DbSet<Account> Accounts { get; set; }
        public FeedbackContext() : base("WebAppCon")
        {

        }
    }
}